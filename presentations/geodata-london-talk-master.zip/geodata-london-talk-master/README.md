## Geo Data London Talk

This repository contains source files for the presentation that accommpanies the talk given at
[Geo-Data London](https://www.eventbrite.co.uk/e/geodata-london-1-tickets-48646251247#) event on 2nd October 2018.

The presentation can be accessed live [here](https://geoinformatics.uk/pages/geodata-london-talk/)

> The slides are advanced by arrow keys or double clicking the screen.
